import React from 'react'

const Notfound = () => {
  return (
    <h1>Page Not Found...</h1>
  )
}

export default Notfound
